public static  String findUsername(UserRole player){
    for (Entry<String, User> entry : usersByUsername.entrySet()) {
	    String key = entry.getKey();
	    User user = entry.getValue();
	    List<UserRole> roles = user.getRoles();
	    for(UserRole role : roles) {
	    	  if(role==player) {
	    		  return user.getUsername();
	    		  }
	    }
	}
	 return null;
  }