public static List<TOPlayableGame> getPlayableGames() throws InvalidInputException {
		Block223 block223 = Block223Application.getBlock223();
		if(!(Block223Application.getCurrentUserRole() instanceof Player)){
			throw new InvalidInputException("Player privileges are required to play a game.");
		}
		Player player = (Player) Block223Application.getCurrentUserRole();
		
		List<TOPlayableGame> result = new ArrayList<TOPlayableGame>();
		List<Game> games = block223.getGames();
		
		for(Game game: games) {
			Boolean published = game.isPublished();
			if(published) {
				TOPlayableGame to = new TOPlayableGame(game.getName(), -1, 0);
				result.add(to);
			}
		}
		List<PlayedGame> playedGames = player.getPlayedGames();
		for(PlayedGame playedGame : playedGames) {
			TOPlayableGame to = new TOPlayableGame(playedGame.getGame().getName(), playedGame.getId(), playedGame.getCurrentLevel());
			result.add(to);
		}
		
		return result;
	}


	public static void selectPlayableGame(String name, int id) throws InvalidInputException  {
			if(!(Block223Application.getCurrentUserRole() instanceof Player)) {
				throw new InvalidInputException("Player privileges are required to play a game.");
			}
			Block223 block223 = Block223Application.getBlock223();
			Game game = block223.findGame(name);
			PlayedGame pgame;
			Player player = (Player) Block223Application.getCurrentUserRole();
			if(game!=null) {
				String username = User.findUsername(player);
				//findUsername(...) needs to be implemented in the User class
				pgame = new PlayedGame(username,game,block223);
				pgame.setPlayer(player);
			}else {
				 pgame = block223.findPlayableGame(id);
				 if(pgame == null) {
						throw new InvalidInputException("The game does not exist.");
				 }
				 if(!pgame.getPlayer().equals(player)) {
					 throw new InvalidInputException("Only the player that started a game can continue the game.");
				 }
				
			}
			Block223Application.setCurrentPlayableGame(pgame);
		}


public static void startGame(Block223PlayModeInterface ui) throws InvalidInputException {
			if(!(Block223Application.getCurrentUserRole() instanceof Player)) {
				throw new InvalidInputException("Player privileges are required to play a game.");
			}
			
			PlayedGame game = Block223Application.getCurrentPlayableGame();
			if(game==null) {
				throw new InvalidInputException("A game must be selected to play it.");
			}
			if((Block223Application.getCurrentUserRole() instanceof Admin) && !game.getPlayer().equals(null) ) {
				throw new InvalidInputException("Player privileges are required to play a game.");
			}
			if((Block223Application.getCurrentUserRole() instanceof Player) && game.getPlayer().equals(null) ) {
				throw new InvalidInputException("Admin privileges are required to test a game.");
			}
			if((Block223Application.getCurrentUserRole() instanceof Admin) && !game.getGame().getAdmin().equals(Block223Application.getCurrentUserRole())){
				throw new InvalidInputException("Only the admin of a game can test the game.");
			}
		
			game.play();
			ui.takeInputs();
			while(game.getPlayStatus()==PlayStatus.Moving) {
				String userInputs = ui.takeInputs();
				//method added below
				updatePaddlePosition(userInputs);
				game.move();	
				
				if(userInputs.contains(" ")) {
					game.pause();
				}
				
				try {
					TimeUnit.MILLISECONDS.sleep((long) game.getWaitTime());
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				ui.refresh();	
			}
			if(game.getPlayStatus()==PlayStatus.GameOver) {
				Block223Application.setCurrentPlayableGame(null);
			}else if(game.getPlayer()!=null) {
				Block223 block223 = Block223Application.getBlock223();
				Block223Persistence.save(block223);
			}
	}

//method used in startGame(Block223PlayModeInterface ui)
	private static void updatePaddlePosition(String userInputs) {
			for(int i = 0; i<userInputs.length(); i++) {
				if(userInputs.charAt(i)==' ') {
					break;
				}
				PlayedGame game = Block223Application.getCurrentPlayableGame();
				if(userInputs.charAt(i)=='l' && (game.getCurrentPaddleX()>0)) {
				 game.setCurrentPaddleX(game.getCurrentPaddleX()+PlayedGame.PADDLE_MOVE_LEFT); 
				}
				if(userInputs.charAt(i)=='r' && (game.getCurrentPaddleX()<(Game.PLAY_AREA_SIDE-game.getCurrentPaddleLength()))) 
				{
				 game.setCurrentPaddleX(game.getCurrentPaddleX()+PlayedGame.PADDLE_MOVE_RIGHT); 
				}
			}
		}


	public static TOCurrentlyPlayedGame getCurrentPlayableGame() throws InvalidInputException {
		if(Block223Application.getCurrentUserRole()==null){
			throw new InvalidInputException("Player privileges are required to play a game.");
		}
		PlayedGame pgame = Block223Application.getCurrentPlayableGame();
		if(pgame==null) {
			throw new InvalidInputException("A game must be selected to play it.");
		}
		if((Block223Application.getCurrentUserRole() instanceof Admin)&&(!pgame.getPlayer().equals(null))){
			throw new InvalidInputException("Player privileges are required to play a game.");
		}
		if((Block223Application.getCurrentUserRole() instanceof Admin) && !pgame.getGame().getAdmin().equals(Block223Application.getCurrentUserRole())){
			throw new InvalidInputException("Only the admin of a game can test the game.");
		}
		if((Block223Application.getCurrentUserRole() instanceof Player) && (pgame.getPlayer().equals(null))){
			throw new InvalidInputException("Admin priveleges are required to test a game.");

		}
		Boolean paused = pgame.getPlayStatus() == PlayStatus.Ready || pgame.getPlayStatus() == PlayStatus.Paused ;
		TOCurrentlyPlayedGame result = new TOCurrentlyPlayedGame(pgame.getGame().getName(), paused, pgame.getScore(), pgame.getLives(), pgame.getCurrentLevel(), pgame.getPlayername(), pgame.getCurrentBallX(), pgame.getCurrentBallY(), pgame.getCurrentPaddleLength(), pgame.getCurrentPaddleX());
	    List<PlayedBlockAssignment> blocks =  pgame.getBlocks();
	    for(PlayedBlockAssignment pblock : blocks) {
	    	  TOCurrentBlock to = new TOCurrentBlock(pblock.getBlock().getRed(), pblock.getBlock().getGreen(), pblock.getBlock().getBlue(), pblock.getBlock().getPoints(), pblock.getX(), pblock.getY(), result);
	    }
	    return result;
	}

