package ca.mcgill.ecse223.block.view;

public interface Block223PlayModeInterface {
	
	public String takeInputs();
	
	public void refresh();

}
